﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTestProject
{
    public interface IVendingMachineState
    {
         void SelectProductAndInsertMoney(int amount, String productName);
         void DispenseProduct();
    }
    public class NoMoneyState : IVendingMachineState
    {
        public void DispenseProduct()
        {
            Console.WriteLine("Vending Machine cannot dispense product because money is not inserted and product is not selected");
        }
        public void SelectProductAndInsertMoney(int amount, string productName)
        {
            if(productName == "cola" && amount == 1.00 ){
            Console.WriteLine(amount + "$ has been inserted and " + productName + " has been dispensed");
            
            }else if(productName == "chips" && amount == 0.50 ){

            }else if(productName == "candy " && amount == 1.00 ){
            }else{
                Console.WriteLine("Cannot Dispace product");
            }
            Console.WriteLine("Thnak you");
        }
    }
    public class HasMoneyState : IVendingMachineState
    {
        public void DispenseProduct()
        {
            Console.WriteLine("Vending Machine  dispensed the product ");
        }
        public void SelectProductAndInsertMoney(int amount, string productName)
        {
            Console.WriteLine("Already Vending machine has money and product selected, So wait till it finish the current dispensing process");
        }
    }
    public class VendingMachine : IVendingMachineState
    {
        //Createing a variable to maintain the internal state
        public IVendingMachineState vendingMachineState { get; set; }
        //Initially the vending machine has NoMoneyState
        public VendingMachine()
        {
            vendingMachineState = new NoMoneyState();
        }
        
        public void SelectProductAndInsertMoney(int amount, string productName)
        {
            vendingMachineState.SelectProductAndInsertMoney(amount, productName);
            // Money has been inserted so vending Machine internal state 
            // changed to 'hasMoneyState'
            if (vendingMachineState is NoMoneyState)
            {
                vendingMachineState = new HasMoneyState();
                Console.WriteLine("VendingMachine internal state has been moved to : "
                                + vendingMachineState.GetType().Name);
            }
        }
        public void DispenseProduct()
        {
            vendingMachineState.DispenseProduct();
            // Product has been dispensed so vending Machine changed the
            // internal state to 'NoMoneyState'
            if (vendingMachineState is HasMoneyState)
            {
                vendingMachineState = new NoMoneyState();
                Console.WriteLine("VendingMachine internal state has been moved to : "
                                + vendingMachineState.GetType().Name);
            }
        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Please Enter the Type of Coins");
             string ObjCoins = Console.ReadLine();
             Console.WriteLine("Please Enter the amount ");
             int ObjAmt = Convert.ToInt32(Console.ReadLine()); 
             if(ObjCoins == "nickels"){
                if(ObjAmt == 20){
                 Console.WriteLine("Current amount {0}",ObjAmt);
                }else{
                   Console.WriteLine("INSERT COIN"); 
                }
             }else if(ObjCoins == "dimes"){
                if(ObjAmt == 10){
                 Console.WriteLine("Current amount {0}",ObjAmt);
                }else{
                   Console.WriteLine("INSERT COIN"); 
                }
             
             }else if(ObjCoins == "quarters"){
                 if(ObjAmt == 4){
                 Console.WriteLine("Current amount {0}",ObjAmt);
                }else{
                   Console.WriteLine("INSERT COIN"); 
                }
             
             }else if(ObjCoins == "pennies"){
                 if(ObjAmt == 100){
                 Console.WriteLine("Current amount {0}",ObjAmt);
                }else{
                   Console.WriteLine("INSERT COIN"); 
                }
             }

            VendingMachine vendingMachine = new VendingMachine();
            Console.WriteLine("Current VendingMachine State : " + vendingMachine.vendingMachineState.GetType().Name + "\n");
            Console.WriteLine("Please Enter the Product Name");
            string ObjProduct = Console.ReadLine();
            Console.WriteLine("Please Enter Amount");
            int ObjAmount = Convert.ToInt32(Console.ReadLine());          
            
            vendingMachine.DispenseProduct();
            
            vendingMachine.SelectProductAndInsertMoney(ObjAmount, ObjProduct);           
            Console.Read();
        }

   
    }

    enum coins { nickels, dimes , quarters, pennies };
}